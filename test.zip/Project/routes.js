var express = require("express");
var routes = express.Router();
   

module.exports = routes;