<?php
echo phpinfo();


?>